﻿namespace UsingDapper.Model
{
    public interface UserModel
    {
        public string LoginID { get; set; }
        public string Password { get; set; }
        public string UserMessage { get; set; }
        public string UserToken { get; set; }   
    }
}
