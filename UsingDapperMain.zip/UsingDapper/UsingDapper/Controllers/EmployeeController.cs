﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UsingDapper.Model;
using UsingDapper.Repo;

namespace UsingDapper.Controllers
{
    [Route("api/[controller]")]
    [ApiController] 
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepo repo;
        public EmployeeController(IEmployeeRepo repo)
        {
            this.repo = repo;
            
        }
        [HttpGet("Get All")]
        public async Task<IActionResult> GetAll()
        {
            var _list=await this.repo.GetAll();
            if (_list != null)
            {
                return Ok(_list);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet("GetbyCode/{code}")]
        public async Task<IActionResult> GetbyCode(int employee_ID)
        {
            var _list = await this.repo.Getbycode(employee_ID);
            if (_list != null)
            {
                return Ok(_list);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPost("Create")]
        public async Task<IActionResult> Create([FromBody] Employee employee)
        {
            var _result = await this.repo.Create(employee);
            return Ok(_result);
            
        }
        [HttpPut("Update")]
        public async Task<IActionResult> Update([FromBody] Employee employee,int employee_ID)
        {
            var _result = await this.repo.Update(employee,employee_ID);
            return Ok(_result);

        }
        [HttpDelete("Remove")]
        public async Task<IActionResult> Remove(int employee_ID)
        {
            var _result = await this.repo.Remove(employee_ID);
            return Ok(_result);

        }


    }
}
