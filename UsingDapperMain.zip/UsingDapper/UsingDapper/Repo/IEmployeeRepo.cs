﻿using UsingDapper.Model;

namespace UsingDapper.Repo
{
    public interface IEmployeeRepo
    {
        Task<List<Employee>> GetAll();
        Task<Employee> Getbycode(int employee_ID);
        Task<string> Create(Employee employee);
        Task<string> Update(Employee employee,int employee_ID);
        Task<string> Remove(int employee_id);
    }
}
