﻿using Dapper;
using System.Data;
using UsingDapper.Model;
using UsingDapper.Model.Data;

namespace UsingDapper.Repo
{
    public class EmployeeRepo : IEmployeeRepo
    {
        private readonly DapperDBContext context;
        public EmployeeRepo(DapperDBContext context)
        {
            this.context = context;
            
        }
        
        public async Task<string> Create(Employee employee)
        {
            string response = string.Empty;
            string query = "Insert into EMPLOYEES(first_name,last_name,email,work_department,salary)values(@first_name,@last_name,@email,@work_department,@salary)";
            var parameters = new DynamicParameters();
            parameters.Add("first_name", employee.first_name, DbType.String);
            parameters.Add("last_name", employee.last_name, DbType.String) ;
            parameters.Add("email", employee.email, DbType.String);
            parameters.Add("work_department", employee.work_department, DbType.String);
            parameters.Add("salary", employee.salary, DbType.String);

            using (var connection = this.context.CreateConnection())
            {
                await connection.ExecuteAsync(query,parameters);
                response = "pass";

            }
            return response;
        }

        public async Task<List<Employee>> GetAll()
        {
            string query = "Select * From EMPLOYEES";
            using(var connection=this.context.CreateConnection())
            {
                var empList=await connection.QueryAsync<Employee>(query);
                return empList.ToList();
            }
        }

        public async Task<Employee> Getbycode(int employee_ID)
        {
            string query = "Select * From EMPLOYEES where employee_ID=@employee_ID";
            using (var connection = this.context.CreateConnection())
            {
                var empList = await connection.QueryFirstOrDefaultAsync<Employee>(query,new {employee_ID} );
                return empList;
            }
        }

        public async Task<string> Remove(int employee_ID)
        {
            string response=string.Empty;
            string query = "Delete From EMPLOYEES where employee_ID=@employee_ID";
            using (var connection = this.context.CreateConnection())
            {
                await connection.ExecuteAsync(query, new { employee_ID });
                response = "pass";

            }
            return response;
        }

        public async Task<string> Update(Employee employee, int employee_ID)
        {
            string response = string.Empty;
            string query = "update EMPLOYEES set first_name=@first_name,last_name=@last_name,email=@email,work_department=@work_department,salary=@salary where employee_ID=@employee_ID";
            var parameters = new DynamicParameters();
            parameters.Add("employee_ID", employee.employee_ID, DbType.String);
            parameters.Add("first_name", employee.first_name, DbType.String);
            parameters.Add("last_name", employee.last_name, DbType.String);
            parameters.Add("email", employee.email, DbType.String);
            parameters.Add("work_department", employee.work_department, DbType.String);
            parameters.Add("salary", employee.salary, DbType.String);
            using (var connection = this.context.CreateConnection())
            {
                await connection.ExecuteAsync(query,parameters);
                response = "pass";

            }
            return response;
        }
    }
}
